package Sergi.MVC.Controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import Sergi.MVC.Model.ArrayTaskList;
import Sergi.MVC.Model.Model;
import Sergi.MVC.Model.Task;
import Sergi.MVC.Model.TaskObserver;
import Sergi.MVC.Model.parse.XMLreadWrite;
import Sergi.MVC.Viewer.AddEditDialog;
import Sergi.MVC.Viewer.MainFrame;

public class Controller {

	static SimpleDateFormat sdf;
	private static Model model = new Model();
	private static MainFrame mainFrame;
	private static Task newTask;

	public Controller() {
		model.addTaskArray(model.readTasksFromFile());
		mainFrame = new MainFrame("��������� �����", model, this);
		mainFrame.initComponents();
		model.registerObserver(mainFrame);
		mainFrame.setVisible(true);
		new TaskObserver(model, this);
	}

	public static void main(String[] args) {
		new Controller();
	}

	public static void showAddDialog(int i) {
		AddEditDialog addDialog;
		TaskData taskData;
		Task task = null;
		if (i == -1) {
			taskData = new TaskData();
		} else {
			task = model.getArrayTaskList().getTask(i);
			taskData = new TaskData(task.getTitle(), task.getStartTime(),
					task.getEndTime(), task.getRepeatCount(), task.isActive());

		}

		addDialog = new AddEditDialog(mainFrame, true, taskData);
		addDialog.setVisible(true);
		if (!addDialog.isDialogCenceled()) {
			newTask = XMLreadWrite.convertTaskDataToTask(taskData);
			if (task != null)
				model.removeTask(task);
			model.addNewTask(newTask);
		}
	}

	public Task[] getTasks() {
		ArrayTaskList arrList = model.getArrayTaskList();
		Task[] tasks = new Task[arrList.size()];
		for (int i = 0; i < arrList.size(); i++) {
			tasks[i] = arrList.getTask(i);
		}
		return tasks;
	}

	public void findTaskIndex(String text) {
		int findedTaskInList = model.getTaskIndex(text);
		if (findedTaskInList != -1)
			mainFrame.enableTaskInList(findedTaskInList);
	}

	public void removeTask(List<Task> list) {
		for (Task task : list) {
			model.removeTask(task);
		}
	}

	public void itsTimeToTask(Task task) {
		JOptionPane.showMessageDialog(mainFrame,
				"����� ��� ������ \"" + task.getTitle() + "\" �������.",
				task.getTitle(), JOptionPane.INFORMATION_MESSAGE);
		model.notifyObservers();
	}
	
	public void exit() {
		model.writeTasksToFile(getTasks());		
		System.exit(0);
	}
}
