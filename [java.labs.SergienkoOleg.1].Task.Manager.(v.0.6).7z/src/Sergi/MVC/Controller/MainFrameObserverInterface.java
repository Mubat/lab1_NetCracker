package Sergi.MVC.Controller;

public interface MainFrameObserverInterface {
	
	void updateTaskList(); 
}
