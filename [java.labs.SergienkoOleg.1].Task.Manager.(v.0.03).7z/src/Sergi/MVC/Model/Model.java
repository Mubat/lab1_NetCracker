package Sergi.MVC.Model;

import java.util.ArrayList;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import Sergi.MVC.Controller.MainFrameObserverInterface;
import Sergi.MVC.Model.parse.Analyzer;
import Sergi.MVC.Model.parse.MyErrHandler;

 /**
  * @author Sergienko Oleg
  * 
  */
public class Model {
    /**
	 * @uml.property  name="arrList"
	 * @uml.associationEnd  multiplicity="(1 1)"
	 */
    private ArrayTaskList arrTaskList = new ArrayTaskList();
    private ArrayList<MainFrameObserverInterface> addEditObservers 
    		= new ArrayList<MainFrameObserverInterface>();; 
    private ArrayList<Task> arrList; 
    public Model() {
    	arrList =  new ArrayList<Task>();
    	
    }
    
    public void addNewTask(Task task) {
        arrTaskList.add(task);
        notifyObservers();
    }
    
 /*   public void addNewTask(ArrayList<Task> tasks) {
        for (Task task : tasks) {
        	arrList.add(task);
		}
    }*/
    
    public void addTaskArray(Task[] tasks) {
        for (int i = 0; i < tasks.length; i++) {
        	arrTaskList.add(tasks[i]);
		}
        notifyObservers();
    }
    
    public void removeTask(Task task) {
        arrTaskList.remove(task);
        notifyObservers();
    }
    
    public ArrayTaskList getArrayTaskList() {
        return arrTaskList;
    }
    
    public ArrayList<Task> getArrayList() {
    	
    	for(int i = 0; i < arrList.size(); i++)
    		arrList.add(arrTaskList.getTask(i));
        return arrList;
    }
    
    public Task getTask(String name) {
        for(Task task : arrTaskList)
            if(task.getTitle().equals(name))
                return task;
        return null;
    }
    
    public Task getTask(Date date) {
        for(Task task : arrTaskList)
            if(task.getTime().equals(date))
                return task;
        return null;
    }
    
    public void registerObserver(MainFrameObserverInterface observer) {
    	addEditObservers.add(observer);
    }
    
    public void removeObserver(MainFrameObserverInterface observer) {
    	addEditObservers.remove(observer);
    }
    
    public void notifyObservers() {
    	for (int i = 0; i < addEditObservers.size(); i++) {
			addEditObservers.get(i).updateTaskList();
		}
    }
    
    public Task[] readTasksFromFile() {
    	Analyzer analyzer = null;
    	try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setValidating(true);
			DocumentBuilder db = dbf.newDocumentBuilder();
			db.setErrorHandler(new MyErrHandler());
			Document doc = db.parse("Tasks.xml");
			if (doc != null) {
				analyzer = new Analyzer();
				analyzer.analyze(doc);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return analyzer.getTaskArray();
    }

	public int getTaskIndex(String taskTitle) {
		for (int i = 0; i < arrTaskList.size(); i++) {
			if(taskTitle.equals(arrTaskList.getTask(i).getTitle()))
				return i;
		}
		return -1;
	}
}
