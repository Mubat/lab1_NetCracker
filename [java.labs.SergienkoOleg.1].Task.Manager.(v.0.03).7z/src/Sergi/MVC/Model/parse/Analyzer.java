package Sergi.MVC.Model.parse;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import Sergi.MVC.Controller.TaskData;
import Sergi.MVC.Model.Task;

public class Analyzer {
	private static Document document;
	private static TaskData newTask;
	private static ArrayList<TaskData> arrList;

	public Analyzer() {
		newTask = new TaskData();
		arrList = new ArrayList<TaskData>();
	}

	/**
	 * Method, which recursively examines the elements XML document and stores
	 * the final document flow.
	 * 
	 * @param node
	 *            variable of type Node which is analyzed.
	 * @param stream
	 *            The stream to which the data are recorded with XML.
	 */
	public void analyze(Node node) {
		switch (node.getNodeType()) {
		case Node.DOCUMENT_NODE: {
			document = (Document) node;
			analyze(document.getDocumentElement());
			break;
		}
		case Node.ELEMENT_NODE: {

			if (node.hasChildNodes()) {
				NodeList children = node.getChildNodes();
				if (node.getNodeName().equals("task")) {
					if (newTask != null ) {
						newTask = new TaskData();
						arrList.add(newTask);
					}
					NamedNodeMap attrs = node.getAttributes();
					for (int i = 0; i < attrs.getLength(); i++)
						analyze(attrs.item(i));
					
				}
				for (int i = 0; i < children.getLength(); i++) {
					analyze(children.item(i));
				}
			}

			analyze(node.getFirstChild());

		} // close switch for ELEMENT_NODE
		case Node.ATTRIBUTE_NODE: {
			if ("name".equals(node.getNodeName()))
				newTask.setTaskName(node.getNodeValue());
			break;
		} // close switch for ATTRIBUTE_NODE
		case Node.TEXT_NODE: {
			switch (node.getParentNode().getNodeName()) {
			case "from": {
				newTask.setDayToBegin(getDate(node.getNodeValue()));
				break;
			}
			case "to": {
				newTask.setDayToEnd(getDate(node.getNodeValue()));
				break;
			}
			case "repeats": {
				newTask.setReps(Integer.parseInt(node.getNodeValue()));
				break;
			}
			case "visibility": {
				newTask.setVisibility(Boolean.parseBoolean(node.getNodeValue()));
				break;
			}
			} // close switch for NodeName
			break;
		}// close switch for type of TEXT_NODE
		}// close switch for type of Node
	}// close switch for method

	// -----------------------------------------------------------------------------
	private static Date getDate(String dateString) {
		DateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm");
		try {
			return sdf.parse(dateString);
		} catch (NullPointerException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public Task[] getTaskArray() {
		Task[] array = new Task[arrList.size()];
		for (int i = 0; i < array.length; i++) {
			array[i] = convertTaskDataToTask(arrList.get(i));
		}
		return array;
	}

	public static Task convertTaskDataToTask(TaskData td) {
		Task newTask = null;
		if (td.getDateToEnd() == null) {
			newTask = new Task(td.getTaskName(), td.getDateToBegin());
			newTask.setActive(td.isActive());
			return newTask;
		}
		newTask = new Task(td.getTaskName(), td.getDateToBegin(),
				td.getDateToEnd(), td.getReps());
		newTask.setActive(td.isActive());
		return newTask;
	}
}