package Sergi.MVC.Controller;

import java.util.Date;

import Sergi.MVC.Model.Model;
import Sergi.MVC.Model.Task;

public class TaskObserver implements Runnable {

	private int sleepSeconds = 30;
	private Model model;
	private Controller control;

	public TaskObserver(Model model, Controller control) {
		this.model = model;
		this.control = control;
		Thread thread = new Thread();
//		thread.run();
		
	}
	
	@Override
	public void run() {
		for(;;) {
			Task[] tasks = control.getTasks();
			for (Task task : tasks) {
				Date date = task.nextTimeAfter(new Date(System.currentTimeMillis()));
				
			}
			try {
				Thread.sleep(1000*sleepSeconds);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Sravneniye dvuh dat
	 * @param from
	 * @param with
	 * @return
	 */
	private boolean equals(Date from, Date with) {
		
		return false;
	}

}
