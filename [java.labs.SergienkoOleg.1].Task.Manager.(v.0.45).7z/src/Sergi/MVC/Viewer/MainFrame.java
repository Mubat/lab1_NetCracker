package Sergi.MVC.Viewer;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import Sergi.MVC.Controller.Controller;
import Sergi.MVC.Controller.MainFrameObserverInterface;
import Sergi.MVC.Model.Model;
import Sergi.MVC.Model.Task;

public class MainFrame extends JFrame implements MainFrameObserverInterface {

	private static final long serialVersionUID = 1L;
	private final String findFieldText = new String("������� �������� ������");

	private Model model;
	private Controller control;
	private JButton addTask;
	private JButton replaceTask;
	private JButton removeTask;
	private AddEditDialog AddDialog;
	private JButton exitButton;
	private JList<Task> jList;// ������ �����
	private JButton findButton;
	private JTextField jtfFind;

	/**
	 * @param title
	 * @throws HeadlessException
	 */
	public MainFrame(String title, Model model, Controller control) {
		super(title);
		this.model = model;
		this.control = control;
	}

	public void initComponents() {
		// this.setLayout(new BorderLayout());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// this.setPreferredSize(new Dimension(600, 700));

		JPanel jEastPanel = new JPanel();
		createButtons(jEastPanel);

		JPanel jWestPanel = new JPanel();
		createTaskList(jWestPanel);

		// ������ �����. ������ ������
		JPanel jSouthPanel = new JPanel();
		createFindPanel(jSouthPanel);

		addFocusListeners();

		addActionListeners();

		pack();
		setLocationRelativeTo(null);
	}

	private void createFindPanel(JPanel southPanel) {

		// southPanel.setLayout(/* new FlowLayout()); */new GridLayout(10, 1));
		jtfFind = new JTextField(findFieldText);
		jtfFind.setName("TextField");
		jtfFind.setColumns(20);
		// System.out.println("\n\n\njList size:" + jList.);
		// jtfFind.setPreferredSize(new Dimension(, jtfFind.getHeight()));
		southPanel.add(jtfFind);
		findButton = new JButton("����� ������");
		southPanel.add(findButton);
		this.add(southPanel, BorderLayout.SOUTH);
	}

	private void createButtons(JPanel jButtonsPanel) {
		jButtonsPanel.setLayout(/* new FlowLayout()); */new GridLayout(4, 1));

		addTask = new JButton(
				"<html><body align = center>��������<br>����� ������</body></html>");
		replaceTask = new JButton(
				"<html><body align = center>�������������<br/>������</body></html>");
		removeTask = new JButton("������� ������");
		removeTask.setEnabled(false);
		exitButton = new JButton("�����");

		jButtonsPanel.add(addTask);
		jButtonsPanel.add(replaceTask);
		jButtonsPanel.add(removeTask);
		jButtonsPanel.add(exitButton);
		this.add(jButtonsPanel, BorderLayout.EAST);

	}

	private void createTaskList(JPanel jPanel) {
		jPanel.setLayout(new BorderLayout(1, 2));
		JLabel text = new JLabel("������ �����", JLabel.CENTER);
		Font font = new Font("Gabriola", Font.BOLD, 24);
		text.setFont(font);
		jPanel.add(text, BorderLayout.NORTH);
		jList = new JList<Task>();
		updateTaskList();
		jPanel.add(jList);
		this.add(jPanel, BorderLayout.CENTER);
	}

	private void addActionListeners() {
		addTask.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Controller.showAddDialog(-1);
			}
		});

		replaceTask.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (jList.getSelectedIndices().length == 1)
					Controller.showAddDialog(jList.getSelectedIndex());
				else
					JOptionPane.showMessageDialog(replaceTask,
							"������� ������ ������ ������� ��� ���������!",
							"������ ����� ������", JOptionPane.ERROR_MESSAGE);
			}
		});

		removeTask.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				control.removeTask(jList.getSelectedValuesList());
			}
		});

		exitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				control.exit();
			}
		});

		jList.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				removeTask.setEnabled(true);
			}
		});

		ActionListener findTaskListener = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				control.findTaskIndex(jtfFind.getText());

			}
		};
		findButton.addActionListener(findTaskListener);
		jtfFind.addActionListener(findTaskListener);

	}

	private void addFocusListeners() {
		jtfFind.addFocusListener(new FocusListener() {

			String enteredData = null;

			@Override
			public void focusLost(FocusEvent arg0) {
				enteredData = jtfFind.getText();
				if (jtfFind.isShowing())
					jtfFind.setText(enteredData.isEmpty() ? findFieldText
							: enteredData);
			}

			@Override
			public void focusGained(FocusEvent arg0) {
				jtfFind.setText(enteredData);
			}
		});
	}

	@Override
	public void updateTaskList() {
		jList.clearSelection();
		jList.setListData(control.getTasks());
		removeTask.setEnabled(false);
	}

	public void enableTaskInList(int index) {
		jList.setSelectedIndex(index);

	}
}
